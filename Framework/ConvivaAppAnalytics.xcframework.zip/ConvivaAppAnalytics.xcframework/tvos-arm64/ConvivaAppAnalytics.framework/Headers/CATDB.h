#import <Foundation/Foundation.h>

FOUNDATION_EXPORT double CATDBVersionNumber;
FOUNDATION_EXPORT const unsigned char CATDBVersionString[];

#import "CATDatabase.h"
#import "CATResultSet.h"
#import "CATDatabaseAdditions.h"
#import "CATDatabaseQueue.h"
#import "CATDatabasePool.h"
