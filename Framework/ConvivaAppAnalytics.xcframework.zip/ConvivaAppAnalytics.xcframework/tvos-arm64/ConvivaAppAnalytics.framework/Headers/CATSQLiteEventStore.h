//
//  CATSQLiteEventStore.h
//  Snowplow
//
//  Copyright (c) 2013-2021 Snowplow Analytics Ltd. All rights reserved.
//
//  This program is licensed to you under the Apache License Version 2.0,
//  and you may not use this file except in compliance with the Apache License
//  Version 2.0. You may obtain a copy of the Apache License Version 2.0 at
//  http://www.apache.org/licenses/LICENSE-2.0.
//
//  Unless required by applicable law or agreed to in writing,
//  software distributed under the Apache License Version 2.0 is distributed on
//  an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
//  express or implied. See the Apache License Version 2.0 for the specific
//  language governing permissions and limitations there under.
//
//  Authors: Jonathan Almeida, Joshua Beemster
//  Copyright: Copyright (c) 2013-2021 Snowplow Analytics Ltd
//  License: Apache License Version 2.0
//

#import <Foundation/Foundation.h>
#import "CATEventStore.h"
#import "CATEmitterEvent.h"

@class CATPayload;
@class CATDatabaseQueue;

NS_SWIFT_NAME(CATSQLiteEventStore)
@interface CATSQLiteEventStore :NSObject <CATEventStore>

/**
 * IMPORTANT: This method is for internal use only. It's signature and behaviour might change in any
 * future tracker release.
 *
 * Clears all the EventStores not associated at any of the namespaces passed as parameter.
 *
 * @param allowedNamespaces The namespace allowed. All the EventStores not associated at any of
 *                          the allowedNamespaces will be cleared.
 * @return The list of namespaces that have been found with EventStores and have been cleared out.
 */
+ (NSArray<NSString *> *)removeUnsentEventsExceptForNamespaces:(NSArray<NSString *> *)allowedNamespaces;

- (instancetype)init NS_UNAVAILABLE;

/**
 *  Basic initializer that creates a database event table (if one does not exist) and then closes the connection.
 */
- (instancetype)initWithNamespace:(NSString *)namespace;

/**
 *  Inserts events into the sqlite table for the app identified with it's bundleId (appId).
 *  @param payload A SnowplowPayload instance to be inserted into the database.
 *  @return If the insert was successful, we return the rowId of the inserted entry, otherwise -1. We explicitly do this in the case of an error, sqlite would return the previous successful insert leading to incorrect data removals.
 */
- (long long int)insertEvent:(CATPayload *)payload;

/**
 *  Finds the row in the event table with the supplied ID.
 *  @param id_ Unique ID of the row in the events table to be returned.
 *  @return A dictionary containing data with keys: 'ID', 'eventData', and 'dateCreated'.
 */
- (CATEmitterEvent *)getEventWithId:(long long int)id_;

/**
 *  Returns all the events in an array of dictionaries.
 *  @return An array with each dictionary element containing key-value pairs of 'date', 'data', 'ID'.
 */
- (NSArray<CATEmitterEvent *> *)getAllEvents;

/**
 *  Returns limited number the events that are NOT pending in an array of dictionaries.
 *  @return An array with each dictionary element containing key-value pairs of 'date', 'data', 'ID'.
 */
- (NSArray<CATEmitterEvent *> *)getAllEventsLimited:(NSUInteger)limit;

/**
 *  The row ID of the last insert made.
 *  @return The row ID of the last insert made.
 */
- (long long int)getLastInsertedRowId;

/**
 *  Returns  the events with size limit.
 *  @return An array with each dictionary element containing key-value pairs of 'date', 'data', 'ID'.
 */
- (NSArray<CATEmitterEvent *> *)getEventsBySizeLimit:(NSUInteger)size;

@end
